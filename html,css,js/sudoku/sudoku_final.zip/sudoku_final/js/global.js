$(document).ready(function() {
    $.getScript("game.js");
});